// datepicker

document.getElementById("start-date").flatpickr();

// datepicker

document.getElementById("end-date").flatpickr();